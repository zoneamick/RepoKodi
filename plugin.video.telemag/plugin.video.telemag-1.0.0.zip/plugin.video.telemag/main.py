# -*- coding: utf-8 -*-
# Module: default
# Author: zoneamick
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys, requests, json
from urllib import urlencode
from urlparse import parse_qsl
try:
    from bs4 import BeautifulSoup
except ImportError:
    import sys
    sys.path.append('/storage/.kodi/addons/script.module.beautifulsoup4/lib')
    from bs4 import BeautifulSoup

import xbmcgui
import xbmcplugin

# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])

def emissions():
    xbmcplugin.setPluginCategory(_handle, 'TeleMag Emissions')
    xbmcplugin.setContent(_handle, 'videos')
    endirect()
    rep = requests.get('http://tele-mag.tv/emission/emissions')##.decode('utf-8' , 'ignore')
    parse = BeautifulSoup(rep.text, 'html.parser')
    arret = parse.find("a", href="http://tele-mag.tv/emission/archive") ## arret aux archives
    pattern = arret.find_all_previous('a',attrs={"href" : lambda L: L and L.startswith('http://tele-mag.tv/emission')})
    pattern.reverse()
    emissions = []
    for p in pattern:
        titre = p['title']
        lien = p['href']
        #emissions.append((titre, lien))
        list_item = xbmcgui.ListItem(label=titre)
        list_item.setInfo('video', { 'title': titre })
        list_item.setInfo('video', { 'plot': titre })
        #list_item.setArt({'thumb': VIDEOS[category][0]['thumb'],
        #                  'icon': VIDEOS[category][0]['thumb'],
        #                  'fanart': VIDEOS[category][0]['thumb']})
        #list_item.setInfo('video', {'aired': "2019-01-01"})       
        list_item.setInfo('video', {'mediatype': 'video'})

        url = get_url(action='episodes', ep=lien)
        is_folder = True
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    xbmcplugin.endOfDirectory(_handle)

def liste_episodes(ep):
    xbmcplugin.setPluginCategory(_handle, 'TeleMag Episodes')
    xbmcplugin.setContent(_handle, 'videos')
    repem1 = requests.get(ep)
    parseem1 = BeautifulSoup(repem1.text, 'html.parser')
    lesblocs = parseem1.find("div", attrs={"class":"paginationEmission"})
    liensblocs = lesblocs.find_all("a")
    lesepisodes = []
    for link in liensblocs[:-1]:
        print(link['href'])
        repemi = requests.get(link['href'])
        objepisodes = BeautifulSoup(repemi.text, 'html.parser')
        blocepisodes = objepisodes.find_all("div", attrs={"class":"bloc1_element_listeVideo"})
        for episode in blocepisodes:
            titre = episode.find('span', attrs={'class':'titreElement_Video'})
            url = episode.find('a')['href']
            ##
            ep = requests.get(url)
            scrapeep = BeautifulSoup(ep.text, 'html.parser')
            desc = scrapeep.find("meta",  property="og:description");
            description = desc['content']

            url2 = str(scrapeep.find("iframe", attrs={'id':'main_video'})['src'])
            req = requests.get(url2)

            parse = BeautifulSoup(req.text, 'html.parser')
            text = parse.find_all('script')
            J = str(text[2])
            J1 = J.split('var config = ')
            J2 = J1[1].rsplit('if (!config.request) {', 1)
            jsontext = J2[0].rsplit(';', 1)
            djeson = json.loads(jsontext[0])
            url = djeson["request"]["files"]["progressive"][0]["url"]
            
            pic = episode.find('img')['src']
            date = episode.find('span', attrs={'class':'MeoElement_Video'})
            lesepisodes.append((titre.text, url, pic, date.text, description))
    for e in lesepisodes:
        #print(e[0].text + " " + e[3].text)

        list_item = xbmcgui.ListItem(label=e[0].encode('utf-8'))

        list_item.setInfo('video', { 'plot': e[3].encode('utf-8') + "\n" + e[4].encode('utf-8') })
        list_item.setInfo('video', { 'aired': e[3].encode('utf-8') })
        list_item.setInfo('video', { 'title': e[0].encode('utf-8'),
                                    'mediatype': 'video'})
        thumb = "http://tele-mag.tv" + e[2]
        list_item.setArt({'thumb': thumb, 'icon': thumb, 'fanart': thumb})

        list_item.setProperty('IsPlayable', 'true')

        url = get_url(action='play', video=e[1].encode('utf-8'))

        is_folder = False
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)

    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_DATEADDED)
    xbmcplugin.endOfDirectory(_handle)

def endirect():
    ytapikey = 'AIzaSyBMVvzQ765VdDPWP7iHaS3joj4Bc7jCWII'
    reqtm = requests.get('http://tele-mag.tv')
    tmparse = BeautifulSoup(reqtm.text, 'html.parser')
    desc = tmparse.find_all('iframe')[0]['src']
    reqytc = requests.get(desc)
    ytparse = BeautifulSoup(reqytc.text, 'html.parser')
    ytvidurl = ytparse.find_all('link')
    ytvid = ytvidurl[1]['href'].split("watch?v=",1)[1]
    yturlapi = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id='+ytvid+'&key='+ytapikey
    ytjson = requests.get(yturlapi).json()
    titre = ytjson["items"][0]["snippet"]["title"]
    thumbnail = ytjson["items"][0]["snippet"]["thumbnails"]["standard"]["url"]
    description = ytjson["items"][0]["snippet"]["description"]
    aired = ytjson["items"][0]["snippet"]["publishedAt"]
    video_url = 'plugin://plugin.video.youtube/play/?video_id='+ytvid

    item = xbmcgui.ListItem(label="[COLOR red][I]"+titre+"[/I][/COLOR]",path=video_url)
    item.setInfo('video', { 'title': titre, 'plot': aired +"\n"+description, 'aired': aired, 'mediatype': 'video'})
    item.setArt({'thumb': thumbnail, 'icon': thumbnail, 'fanart': thumbnail})
    xbmcplugin.addDirectoryItem(_handle, video_url, item, False)

    #item.setInfo('video', {'mediatype': 'video'})
    #xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
    #player = KKPlayer(mainurl=url)
    #player.play(video_url,item)
    #while player._playbackLock:
    #    player._trackPosition()
    #    xbmc.sleep(1000)

def get_url(**kwargs):
    """
    Create a URL for calling the plugin recursively from the given set of keyword arguments.

    :param kwargs: "argument=value" pairs
    :type kwargs: dict
    :return: plugin call URL
    :rtype: str
    """
    return '{0}?{1}'.format(_url, urlencode(kwargs))


def get_categories():
    """
    Get the list of video categories.

    Here you can insert some parsing code that retrieves
    the list of video categories (e.g. 'Movies', 'TV-shows', 'Documentaries' etc.)
    from some site or server.

    .. note:: Consider using `generator functions <https://wiki.python.org/moin/Generators>`_
        instead of returning lists.

    :return: The list of video categories
    :rtype: types.GeneratorType
    """
    return VIDEOS.iterkeys()


def get_videos(category):
    """
    Get the list of videofiles/streams.

    Here you can insert some parsing code that retrieves
    the list of video streams in the given category from some site or server.

    .. note:: Consider using `generators functions <https://wiki.python.org/moin/Generators>`_
        instead of returning lists.

    :param category: Category name
    :type category: str
    :return: the list of videos in the category
    :rtype: list
    """
    return VIDEOS[category]


def list_categories():
    """
    Create the list of video categories in the Kodi interface.
    """
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(_handle, 'My Video Collection')
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(_handle, 'videos')
    # Get video categories
    categories = get_categories()
    # Iterate through categories
    for category in categories:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=category)
        list_item.setInfo('video', { 'plot': "Ceci est un test" })
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        list_item.setArt({'thumb': VIDEOS[category][0]['thumb'],
                          'icon': VIDEOS[category][0]['thumb'],
                          'fanart': VIDEOS[category][0]['thumb']})
        # Set additional info for the list item.
        # Here we use a category name for both properties for for simplicity's sake.
        # setInfo allows to set various information for an item.
        # For available properties see the following link:
        # https://codedocs.xyz/xbmc/xbmc/group__python__xbmcgui__listitem.html#ga0b71166869bda87ad744942888fb5f14
        # 'mediatype' is needed for a skin to display info for this ListItem correctly.
        list_item.setInfo('video', {'title': category,
                                    'genre': category,
                                    'mediatype': 'video'})
        list_item.setInfo('video', {'aired': "2019-01-01"})
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=listing&category=Animals
        url = get_url(action='listing', category=category)
        # is_folder = True means that this item opens a sub-list of lower level items.
        is_folder = True
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    # xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_handle)


def list_videos(category):
    """
    Create the list of playable videos in the Kodi interface.

    :param category: Category name
    :type category: str
    """
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(_handle, category)
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(_handle, 'videos')
    # Get the list of videos in the category.
    videos = get_videos(category)
    # Iterate through videos.
    for video in videos:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=video['name'])

        # Set additional info for the list item.
        desc = "description du video"
        list_item.setInfo('video', { 'plot': desc })
        date = "2009-04-05 00:00:00"
        list_item.setInfo('video', { 'aired': date })
        # 'mediatype' is needed for skin to display info for this ListItem correctly.
        list_item.setInfo('video', {'title': video['name'],
                                    'genre': video['genre'],
                                    'mediatype': 'video'})
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        list_item.setArt({'thumb': video['thumb'], 'icon': video['thumb'], 'fanart': video['thumb']})
        # Set 'IsPlayable' property to 'true'.
        # This is mandatory for playable items!
        list_item.setProperty('IsPlayable', 'true')
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=play&video=http://www.vidsplay.com/wp-content/uploads/2017/04/crab.mp4
        url = get_url(action='play', video=video['video'])
        # Add the list item to a virtual Kodi folder.
        # is_folder = False means that this item won't open any sub-list.
        is_folder = False
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_handle)


def play_video(path):
    """
    Play a video by the provided path.

    :param path: Fully-qualified video URL
    :type path: str
    """
    # Create a playable item with a path to play.
    play_item = xbmcgui.ListItem(path=path)
    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring: URL encoded plugin paramstring
    :type paramstring: str
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin
    if params:
        if params['action'] == 'listing':
            # Display the list of videos in a provided category.
            list_videos(params['category'])
        elif params['action'] == 'episodes':
            liste_episodes(params['ep'])
        elif params['action'] == 'play':
            # Play a video from a provided URL.
            play_video(params['video'])
        else:
            # If the provided paramstring does not contain a supported action
            # we raise an exception. This helps to catch coding errors,
            # e.g. typos in action names.
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        # If the plugin is called from Kodi UI without any parameters,
        # display the list of video categories
        #list_categories()
        emissions()


if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
    router(sys.argv[2][1:])
